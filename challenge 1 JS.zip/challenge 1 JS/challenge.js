function ageindays(){
var birthyear=prompt('What year were you born.. ')
var Ageindays=(2022-birthyear)*365
var h1=document.createElement('h1')
var textanswer=document.createTextNode('you are '+Ageindays+' days old')
h1.setAttribute['id','ageindays']
h1.appendChild(textanswer)
document.getElementById('flex-box-result').appendChild(h1)
}
function reset(){
  document.getElementById('ageindays').remove()
}
